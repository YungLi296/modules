#!/system/bin/sh
# 只保留需要 magisk/root 域、镜像侧无法完成的功能。

MODDIR=${0%/*}
LOG=/data/adb/tb710fu_runtime.log
log() { echo "$(date '+%F %T') [rt] $*" >> "$LOG"; }
log "runtime service 启动"

i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 60 ]; do
    sleep 2
    i=$((i + 1))
done

# 1) 亮屏方式联动：init 域读不到 Settings，必须由本模块轮询
if [ -n "$(getprop init.svc.tb_gesture)" ]; then
    setprop ctl.stop tb_gesture 2>/dev/null
    log "已停止镜像内 tb_gesture"
fi
sh "$MODDIR/bin/gesture_bridge.sh" >/dev/null 2>&1 &
log "gesture_bridge 已拉起"

# 2) iorapd 噪音抑制：本机无 /dev/iorap_dev，init 反复重启
sh "$MODDIR/bin/quiet_noise.sh" >/dev/null 2>&1 &
log "quiet_noise 已拉起"

# 3) ZUI 相机拍照：morpho 厂商校验
# libmorpho_ImageRefiner / libmorpho_auto_framing 是 Lenovo maker-limited 版，
# native 层读 ro.product.manufacturer；Xiaomi 会导致拍照/人像追踪 SIGILL。
# 必须 zygote 之后注入：Java Build.MANUFACTURER 已被 zygote 快照为 Xiaomi，不受影响。
resetprop ro.product.manufacturer Lenovo 2>/dev/null && log "ro.product.manufacturer -> Lenovo"

# 4) 官方 OTA 按 uid 封锁（小米把 updater 列为 core package，pm disable 无效）
get_uid() {
    u=$(stat -c %u /data/data/com.android.updater 2>/dev/null)
    [ -z "$u" ] && u=$(awk '$1=="com.android.updater"{print $2}' /data/system/packages.list 2>/dev/null)
    [ -z "$u" ] && u=$(pm list packages -U 2>/dev/null | awk '/^package:com\.android\.updater /{sub(/.*uid:/,"");print;exit}')
    echo "$u"
}

UPD_UID=""
k=0
while [ -z "$UPD_UID" ] && [ $k -lt 10 ]; do
    UPD_UID=$(get_uid)
    [ -z "$UPD_UID" ] && sleep 6
    k=$((k + 1))
done

if [ -n "$UPD_UID" ]; then
    n=0
    while [ $n -lt 5 ]; do
        for T in iptables ip6tables; do
            $T -C OUTPUT -m owner --uid-owner "$UPD_UID" -j REJECT 2>/dev/null || \
            $T -I OUTPUT -m owner --uid-owner "$UPD_UID" -j REJECT 2>/dev/null
        done
        if iptables -C OUTPUT -m owner --uid-owner "$UPD_UID" -j REJECT 2>/dev/null; then
            log "iptables 已封锁 updater(uid=$UPD_UID)"
            break
        fi
        n=$((n + 1))
        sleep 5
    done
else
    log "警告: 取不到 updater uid"
fi

# 二次确认：极少数流程会在 boot_completed 之后重写产品属性
if [ "$(getprop ro.product.manufacturer)" != "Lenovo" ]; then
    resetprop ro.product.manufacturer Lenovo 2>/dev/null
    log "二次确认 ro.product.manufacturer -> Lenovo"
fi

log "runtime service 初始化完成"
