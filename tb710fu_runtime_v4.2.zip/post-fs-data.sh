#!/system/bin/sh
# 必须早于 system_server / 蓝牙栈初始化的属性。
# 镜像 rc 在 boot_completed 才设，对这两项属于事后改，不生效。

LOG=/data/adb/tb710fu_runtime.log
log() { echo "$(date '+%F %T') [pfd] $*" >> "$LOG"; }
log "post-fs-data 开始"

# 144Hz：RefreshRatePolicy 在 system_server 构造时读取静态字段
for P in \
    persist.sys.smartpower.limit.max.refresh.rate \
    persist.sys.smartpower.limit.normal.max.refresh.rate.support
do
    if [ "$(getprop "$P")" != "144" ]; then
        resetprop "$P" 144 && log "$P -> 144"
    fi
done

# mipp：必须早于蓝牙栈初始化，否则 /dev/mipp_pen0 分支导致 BLE 键鼠无响应
if [ "$(getprop persist.vendor.bluetooth.mipp.supported)" != "false" ]; then
    resetprop persist.vendor.bluetooth.mipp.supported false
    log "mipp.supported -> false"
fi

# 其余 6 个蓝牙属性必须保持 piano（本机与小米平板8 Pro 同为 SM8650）
CUR_DEVICE=$(getprop ro.product.device)
for P in \
    persist.vendor.bluetooth.lhdc_v4.supported \
    persist.vendor.bluetooth.lhdc_v5.supported \
    persist.vendor.bluetooth.bqr.supported \
    persist.vendor.bluetooth.adaptive_sampler.supported \
    persist.vendor.bluetooth.echo.supported \
    persist.vendor.bluetooth.skip.rfcomm.auth
do
    V=$(getprop "$P")
    if [ "$V" != "piano" ] && [ "$V" != "$CUR_DEVICE" ]; then
        resetprop "$P" piano
        log "$P -> piano"
    fi
done

log "post-fs-data 完成"
