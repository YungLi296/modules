#!/system/bin/sh
# 安装时补执行位（zip 已写 Unix 权限，这里兜一层）
ui_print "- 设置脚本权限"
chmod 755 "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/uninstall.sh" 2>/dev/null
chmod 755 "$MODPATH/bin/"*.sh 2>/dev/null
