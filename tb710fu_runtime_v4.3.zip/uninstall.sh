#!/system/bin/sh
# 卸载还原（v3.0）
# 把合并前各模块改过的 persist 属性恢复原值 —— persist.* 会写进
# /data/property/persistent_properties，不还原会长期残留。

# 144Hz（原 tb710fu_ddc_fix）→ 机型原值 120，与 /product/etc/build.prop 一致
resetprop persist.sys.smartpower.limit.max.refresh.rate 120
resetprop persist.sys.smartpower.limit.normal.max.refresh.rate.support 120

# mipp（原 bt_mipp_fix）→ 原始值 piano
resetprop persist.vendor.bluetooth.mipp.supported piano

# 日志与状态
rm -f /data/adb/tb710fu_runtime.log
rm -f /data/adb/tb710fu_gesture.log
rm -rf /data/adb/tb710fu_bt

# 手写笔桥接（v4.3）：先停 CPS GPIO 持线助手并释放（GPIO 归 vendor
# DSI/panel 驱动所有，留在置位会导致黑屏——上游事故教训），再清状态。
if [ -r /data/adb/tb710fu_rt/cps-gpio.pid ]; then
    _pen_pid=$(cat /data/adb/tb710fu_rt/cps-gpio.pid 2>/dev/null)
    case "$_pen_pid" in
        ''|*[!0-9]*) ;;
        *) kill "$_pen_pid" 2>/dev/null ;;
    esac
fi
[ -x /system/bin/gpioset ] && /system/bin/gpioset gpiochip0 10=0 108=0 >/dev/null 2>&1
rm -rf /data/adb/tb710fu_rt

# 运行期锁（/dev 是 tmpfs，重启自清；这里一并收掉改名前的历史遗留）
rm -rf /dev/.tb710fu_gesture.lock
rm -rf /dev/tb710fu_coverfix.gesture.lock
