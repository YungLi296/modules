#!/system/bin/sh
# 安装时补执行位（zip 已写 Unix 权限，这里兜一层）
ui_print "- 设置脚本权限"
chmod 755 "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/uninstall.sh" 2>/dev/null
chmod 755 "$MODPATH/bin/"*.sh 2>/dev/null
chmod 755 "$MODPATH/bin/pen-cps-gpio" 2>/dev/null

# PenHidCtl 保持上游原签名，只作为 priv-app 覆盖层随系统扫描加载；
# 不能用 pm install 装（会变 /data/app 应用并丢特权蓝牙权限）。
if [ -f "$MODPATH/system/priv-app/aclpenhid/PenHidCtl.apk" ]; then
    ui_print "- PenHidCtl（手写笔 HID 回连控制器）已放入 priv-app"
fi
