#!/system/bin/sh
# 安装时补执行位（zip 已写 Unix 权限，这里兜一层）
ui_print "- 设置脚本权限"
chmod 755 "$MODPATH/service.sh" "$MODPATH/post-fs-data.sh" "$MODPATH/uninstall.sh" 2>/dev/null
chmod 755 "$MODPATH/bin/"*.sh 2>/dev/null
chmod 755 "$MODPATH/bin/pen-cps-gpio" 2>/dev/null
chmod 644 "$MODPATH/system/vendor/lib64/hw/displayfeature.default.so" 2>/dev/null

# 护眼矩阵参数（v4.5）：存在就不覆盖，方便用户自己调
mkdir -p /data/adb/tb710fu_rt
[ -f /data/adb/tb710fu_rt/eye_care.conf ] || cat >/data/adb/tb710fu_rt/eye_care.conf <<'EOF'
# 护眼矩阵可调参数。改完重启设备生效（脚本只在开机由 service.sh 拉起）。
# 暖色衰减：每 100 强度，绿通道降 WARM_G/10000，蓝通道降 WARM_B/10000
WARM_G=1600
WARM_B=4500
# 纸质色彩-淡彩的饱和度（万分比）：10000=全彩 0=黑白
SAT_PALE=6000
EOF

# PenHidCtl 保持上游原签名，只作为 priv-app 覆盖层随系统扫描加载；
# 不能用 pm install 装（会变 /data/app 应用并丢特权蓝牙权限）。
if [ -f "$MODPATH/system/priv-app/aclpenhid/PenHidCtl.apk" ]; then
    ui_print "- PenHidCtl（手写笔 HID 回连控制器）已放入 priv-app"
fi
