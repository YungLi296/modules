#!/system/bin/sh
# 只保留需要 magisk/root 域、镜像侧无法完成的功能。

MODDIR=${0%/*}
LOG=/data/adb/tb710fu_runtime.log
log() { echo "$(date '+%F %T') [rt] $*" >> "$LOG"; }
log "runtime service 启动"

i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 60 ]; do
    sleep 2
    i=$((i + 1))
done

# 1) 亮屏方式联动：init 域读不到 Settings，必须由本模块轮询
if [ -n "$(getprop init.svc.tb_gesture)" ]; then
    setprop ctl.stop tb_gesture 2>/dev/null
    log "已停止镜像内 tb_gesture"
fi
sh "$MODDIR/bin/gesture_bridge.sh" >/dev/null 2>&1 &
log "gesture_bridge 已拉起"

# 2) iorapd 噪音抑制：本机无 /dev/iorap_dev，init 反复重启
sh "$MODDIR/bin/quiet_noise.sh" >/dev/null 2>&1 &
log "quiet_noise 已拉起"

# 3) ZUI 相机拍照：morpho 厂商校验
# libmorpho_ImageRefiner / libmorpho_auto_framing 是 Lenovo maker-limited 版，
# native 层读 ro.product.manufacturer；Xiaomi 会导致拍照/人像追踪 SIGILL。
# 必须 zygote 之后注入：Java Build.MANUFACTURER 已被 zygote 快照为 Xiaomi，不受影响。
resetprop ro.product.manufacturer Lenovo 2>/dev/null && log "ro.product.manufacturer -> Lenovo"

# 4) 官方 OTA 按 uid 封锁（小米把 updater 列为 core package，pm disable 无效）
get_uid() {
    u=$(stat -c %u /data/data/com.android.updater 2>/dev/null)
    [ -z "$u" ] && u=$(awk '$1=="com.android.updater"{print $2}' /data/system/packages.list 2>/dev/null)
    [ -z "$u" ] && u=$(pm list packages -U 2>/dev/null | awk '/^package:com\.android\.updater /{sub(/.*uid:/,"");print;exit}')
    echo "$u"
}

UPD_UID=""
k=0
while [ -z "$UPD_UID" ] && [ $k -lt 10 ]; do
    UPD_UID=$(get_uid)
    [ -z "$UPD_UID" ] && sleep 6
    k=$((k + 1))
done

if [ -n "$UPD_UID" ]; then
    n=0
    while [ $n -lt 5 ]; do
        for T in iptables ip6tables; do
            $T -C OUTPUT -m owner --uid-owner "$UPD_UID" -j REJECT 2>/dev/null || \
            $T -I OUTPUT -m owner --uid-owner "$UPD_UID" -j REJECT 2>/dev/null
        done
        if iptables -C OUTPUT -m owner --uid-owner "$UPD_UID" -j REJECT 2>/dev/null; then
            log "iptables 已封锁 updater(uid=$UPD_UID)"
            break
        fi
        n=$((n + 1))
        sleep 5
    done
else
    log "警告: 取不到 updater uid"
fi

# 二次确认：极少数流程会在 boot_completed 之后重写产品属性
if [ "$(getprop ro.product.manufacturer)" != "Lenovo" ]; then
    resetprop ro.product.manufacturer Lenovo 2>/dev/null
    log "二次确认 ro.product.manufacturer -> Lenovo"
fi

# 5) 手写笔桥接（v4.3，原 tb710fu_pen_bridge）：磁吸 CPS 上电、磁吸胶囊、
#    HID Host 回连、pen_wakeup 参数守护。脚本自带 flock 单例 + respawn，
#    这里只负责拉起一次；停用开关是 /data/adb/tb710fu_rt/disable。
if [ ! -e /data/adb/tb710fu_rt/disable ]; then
    sh "$MODDIR/bin/pen_bridge.sh" >/dev/null 2>&1 &
    log "pen_bridge 已拉起（手写笔桥接）"
else
    log "pen_bridge 已跳过：存在 /data/adb/tb710fu_rt/disable"
fi

# 6) 护眼色彩矩阵下发（v4.5，原 tb710fu_eyecare）：HyperOS framework 的 displayfeature
#    请求在本机全落空（vendor HAL 是空壳），唯一出口是 SurfaceFlinger display 级矩阵。
#    模块自带空壳 displayfeature.default.so 保住 HAL 链路不报错，实际矩阵由
#    bin/eye_care.sh 轮询 dumpsys displayfeature 后下发（护眼强度 + 纸质色彩 全彩/淡彩/黑白）。
#    停用开关：/data/adb/tb710fu_rt/disable_eye
if [ ! -e /data/adb/tb710fu_rt/disable_eye ]; then
    if [ -f /data/adb/tb710fu_rt/eye_care.pid ]; then
        _old=$(cat /data/adb/tb710fu_rt/eye_care.pid 2>/dev/null)
        case "$_old" in ''|*[!0-9]*) ;; *) kill "$_old" 2>/dev/null ;; esac
        rm -f /data/adb/tb710fu_rt/eye_care.pid
    fi
    sh "$MODDIR/bin/eye_care.sh" >/dev/null 2>&1 &
    echo $! >/data/adb/tb710fu_rt/eye_care.pid
    log "eye_care 已拉起 pid=$(cat /data/adb/tb710fu_rt/eye_care.pid)（护眼色彩矩阵）"
else
    log "eye_care 已跳过：存在 /data/adb/tb710fu_rt/disable_eye"
fi

# 7) 系统语音识别服务注册(v4.4):IME 悬浮工具条的麦克风键走框架 SpeechRecognizer
#    → secure 设置 voice_recognition_service。移植 data 全新导致该设置缺失 → 麦克风键
#    死按钮(点击无响应无日志)。底包自带 com.xiaomi.mibrain.speech/.asr.AsrService
#    (声明 android.speech.RecognitionService),只是没被注册。仅空缺时写入,
#    不覆盖后续改动;settings_secure.xml 持久化。A/B 实测(2026-11-18):
#    delete → 语音键无响应;put → 面板弹出且正常录音。
VRS=$(settings get secure voice_recognition_service 2>/dev/null)
if [ -z "$VRS" ] || [ "$VRS" = "null" ]; then
    settings put secure voice_recognition_service \
        com.xiaomi.mibrain.speech/.asr.AsrService && \
        log "voice_recognition_service -> com.xiaomi.mibrain.speech/.asr.AsrService（原为空）"
fi

log "runtime service 初始化完成"
