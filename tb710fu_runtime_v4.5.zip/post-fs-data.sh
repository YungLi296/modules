#!/system/bin/sh
# 必须早于 system_server / 蓝牙栈初始化的属性。
# 镜像 rc 在 boot_completed 才设，对这两项属于事后改，不生效。

LOG=/data/adb/tb710fu_runtime.log
log() { echo "$(date '+%F %T') [pfd] $*" >> "$LOG"; }
log "post-fs-data 开始"

# 144Hz：RefreshRatePolicy 在 system_server 构造时读取静态字段
for P in \
    persist.sys.smartpower.limit.max.refresh.rate \
    persist.sys.smartpower.limit.normal.max.refresh.rate.support
do
    if [ "$(getprop "$P")" != "144" ]; then
        resetprop "$P" 144 && log "$P -> 144"
    fi
done

# mipp：必须早于蓝牙栈初始化，否则 /dev/mipp_pen0 分支导致 BLE 键鼠无响应
if [ "$(getprop persist.vendor.bluetooth.mipp.supported)" != "false" ]; then
    resetprop persist.vendor.bluetooth.mipp.supported false
    log "mipp.supported -> false"
fi

# 其余 6 个蓝牙属性必须保持 piano（本机与小米平板8 Pro 同为 SM8650）
CUR_DEVICE=$(getprop ro.product.device)
for P in \
    persist.vendor.bluetooth.lhdc_v4.supported \
    persist.vendor.bluetooth.lhdc_v5.supported \
    persist.vendor.bluetooth.bqr.supported \
    persist.vendor.bluetooth.adaptive_sampler.supported \
    persist.vendor.bluetooth.echo.supported \
    persist.vendor.bluetooth.skip.rfcomm.auth
do
    V=$(getprop "$P")
    if [ "$V" != "piano" ] && [ "$V" != "$CUR_DEVICE" ]; then
        resetprop "$P" piano
        log "$P -> piano"
    fi
done

# 移植者署名（中文）被写进了标准 build 属性，其中 ro.build.user 会让把
# Build.USER 塞进 HTTP header 的 App 直接崩：OkHttp 的 header 值只允许可见
# ASCII，中文会抛 IllegalArgumentException: Unexpected char 0x9177 ...
# 实证：com.orion.notein（Notein 笔记）device_info header 里带
# user:"酷安@完美要永恒" → 启动即 FATAL。
# Build 类在 zygote 启动时快照，必须在本阶段（zygote 之前）改，Java 侧才生效；
# 系统起来后再 resetprop 只影响 native，Java Build.USER 仍是旧值。
if [ "$(getprop ro.build.user)" != "LXY" ]; then
    resetprop ro.build.user LXY && log "ro.build.user -> LXY（原值为中文署名）"
fi
# Build.DISPLAY 同样是署名（"CP2A.260605.016 (酷安@完美要永恒)"），
# 去掉括号部分，保留标准版本号。用 sed 而不是 ${var%% (*}：
# mksh 对 pattern 里的括号解析不可靠。
DISP=$(getprop ro.build.display.id)
DISP_BASE=$(printf '%s' "$DISP" | sed 's/[[:space:]]*(.*$//')
if [ -n "$DISP_BASE" ] && [ "$DISP" != "$DISP_BASE" ]; then
    resetprop ro.build.display.id "$DISP_BASE" && log "ro.build.display.id -> $DISP_BASE"
fi

# ro.mi.os.version.incremental 也被写了署名("OS4.0.5.0.XPYCNXM.酷安@完美要永恒")。
# 小米 AccessClient 把 "model;mi.os.version.incremental" 拼进 User-Agent,中文触发
# OkHttp 的 header 校验 IllegalArgumentException: Unexpected char 0x9177 →
# 请求根本没发出去,被当成网络错误 → 小爱语音/对话报「没有联网」。
# 实测(2026-11-18):UA 干净后 AccessClient 全部 200,小爱助手对话恢复。
# 处理:含非可见 ASCII 就用 ro.build.version.incremental(干净官方值)整体替换;
# 不硬编码版本号,底包升级自动适配。自建 OTA 用的是 ro.build.version.incremental,
# 不受本属性影响(ota_check.sh 第 49 行)。
# 注:2026-11-18 曾按用户决策回退,同日实测证明小爱助手对话/查找设备相关云链路
# 需要干净 UA,经用户同意恢复本修复。
MIV=$(getprop ro.mi.os.version.incremental)
if printf '%s' "$MIV" | grep -q '[^ -~]'; then
    CLEAN=$(getprop ro.build.version.incremental)
    if [ -n "$CLEAN" ]; then
        resetprop ro.mi.os.version.incremental "$CLEAN" && \
            log "ro.mi.os.version.incremental -> $CLEAN（原值含非 ASCII）"
    fi
fi

log "post-fs-data 完成"
